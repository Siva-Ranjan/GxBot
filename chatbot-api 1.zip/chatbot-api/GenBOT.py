from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector
import spacy

app = Flask(__name__)
CORS(app)

# MySQL Connection Configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'bot'
}

# Load employee data from MySQL
def load_employee_data():
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor(dictionary=True)
    cursor.execute("SELECT * FROM employees")
    employee_data = cursor.fetchall()
    cursor.close()
    connection.close()
    return employee_data

# Find employees based on keyword
def find_employee(keyword, employee_data):
    matches = []
    for employee in employee_data:
        for key, value in employee.items():
            if keyword.lower() in str(value).lower():
                matches.append(employee)
                break
    return matches

@app.route('/employee-info', methods=['POST'])
def get_employee_info():
    data = request.json
    user_input = data['user_input']
    
    nlp = spacy.load('en_core_web_sm')
    doc = nlp(user_input)
    keywords = [chunk.text for chunk in doc.noun_chunks]

    if not keywords:
        return jsonify({"message": "Please provide more specific information."}), 400

    employee_data = load_employee_data()

    found_employees = []
    for keyword in keywords:
        found_employees.extend(find_employee(keyword, employee_data))

    if found_employees:
        return jsonify({"employees": found_employees}), 200
    else:
        return jsonify({"message": "No matching employee found."}), 404

if __name__ == '__main__':
    app.run(debug=True)

