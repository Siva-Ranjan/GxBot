const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Endpoint to handle incoming chatbot messages
app.post('/chatbot', (req, res) => {
    const userInput = req.body.message;

    // Replace this with your chatbot logic
    const botResponse = `Received message: ${userInput}`;

    // Send the bot's response back to the client
    res.json({ response: botResponse });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});

